from Crypto import Cipher
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

# decrypt
ciphertext = open('secret.txt','rb').read()
pr_key = RSA.importKey(open('private.pem','r').read())
decrypted = PKCS1_OAEP.new(pr_key).decrypt(ciphertext)
print(decrypted)