from cloudcompass import amazonlightsail
import streamlit as st 


lst = amazonlightsail.services_list()
st.markdown(lst)

