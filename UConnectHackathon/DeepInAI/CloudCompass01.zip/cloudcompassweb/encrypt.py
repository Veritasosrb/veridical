from Crypto import Cipher
from Crypto.Cipher import PKCS1_OAEP
from Crypto.PublicKey import RSA

# privKEY,pubKey
private_key = RSA.generate(2048) # shortened for testing
public_key = private_key.publickey()
# 'convert' really store
with open('private.pem','w') as pr:
  pr.write(private_key.exportKey().decode())
with open('public.pem','w') as pu:
  pu.write(public_key.exportKey().decode())

# encrypt
message = 'Hum apke hai kon ?'.encode()
pu_key = RSA.importKey(open('public.pem','r').read())
ciphertext = PKCS1_OAEP.new(pu_key).encrypt(message)
with open('secret.txt','wb') as f:
  f.write(ciphertext)

print('task complete')


