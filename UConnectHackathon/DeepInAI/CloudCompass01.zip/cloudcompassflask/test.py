import AmazonLightsail

root = AmazonLightsail.root
service_tuple = 2

# for i in root[]

# Get list of all services available in amazon lightsail
def services_list():
    return {root['products'][i]['productFamily'] for i in root['products']}

# Get count of services available in amazon lightsail
def services_count():
    print(len(services_list()))

# Get list of all attributes available for a service
def service_attributes():
    return(root['products']['BD6CCGKBZGJQSHXD']['attributes'].keys())

def publicationDate():
    return root['publicationDate']

def offerCode():
    return root['offerCode']


print(root.keys())
print(len(root['products'].keys()))

    

    