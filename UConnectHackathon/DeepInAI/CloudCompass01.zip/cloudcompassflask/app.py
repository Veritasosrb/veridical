from flask import Flask
from flask_restful import Resource, Api
import AmazonLightsail

app = Flask(__name__)
api = Api(app)

class HelloWorld(Resource):
    def get(self):
        return AmazonLightsail.root
api.add_resource(HelloWorld, '/resource/1')


if __name__ == "__main__":
    app.run(debug=True)
    