root =  {
    "formatVersion": "v1.0",
    "disclaimer": "This pricing list is for informational purposes only. All prices are subject to the additional terms included in the pricing pages on http://aws.amazon.com. All Free Tier prices are also subject to the terms included at https://aws.amazon.com/free/",
    "offerCode": "AmazonLightsail",
    "version": "20210520223117",
    "publicationDate": "2021-05-20T22:31:17Z",
    "products": {
      "3AH8K7VT3GHZD2CN": {
        "sku": "3AH8K7VT3GHZD2CN",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Paris)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUW3-BundleUsage:1GB",
          "operation": "Bundle:1GB",
          "dataTransferQuota": "2TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "M3B37R8F9EDVFNMR": {
        "sku": "M3B37R8F9EDVFNMR",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "CAN1-BundleUsage:16GB_win",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "6TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "UPAK58F8DKHFBHDM": {
        "sku": "UPAK58F8DKHFBHDM",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Middle East",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "ME-CDN:500GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:500GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "4DZSP3Y8VQWVXGSM": {
        "sku": "4DZSP3Y8VQWVXGSM",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APN2-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "3GJNEYQUMEU84S9S": {
        "sku": "3GJNEYQUMEU84S9S",
        "productFamily": "Lightsail Snapshot",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "group": "Lightsail Snapshot",
          "groupDescription": "Amount of Lightsail Snapshots in GB-Month",
          "usagetype": "EUC1-SnapshotUsage",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "8GYMZUNC2Y2RES96": {
        "sku": "8GYMZUNC2Y2RES96",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "EUW2-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "F73URYY329ZPRJZQ": {
        "sku": "F73URYY329ZPRJZQ",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "group": "Lightsail unused static IP",
          "groupDescription": "Number of unused Lightsail static IP hours",
          "usagetype": "EUW2-UnusedStaticIP",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "BD6CCGKBZGJQSHXD": {
        "sku": "BD6CCGKBZGJQSHXD",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Stockholm)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUN1-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "46VSFPMBBCY9UMPP": {
        "sku": "46VSFPMBBCY9UMPP",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS3-BundleUsage:32GB_win",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "3.5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "ZXB24WZC7SE6UBV8": {
        "sku": "ZXB24WZC7SE6UBV8",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APN2-BundleUsage:2GB_win",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "XCUATWSZS5P5SQAJ": {
        "sku": "XCUATWSZS5P5SQAJ",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "240GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUC1-DatabaseUsage:8GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.2TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "PWW7T9AS56KTM25X": {
        "sku": "PWW7T9AS56KTM25X",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "240GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EU-DatabaseUsage:8GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.2TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "JNFJ7F3V43NBPFJ4": {
        "sku": "JNFJ7F3V43NBPFJ4",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Tokyo)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APN1-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "VHANY6NT9U522MSM": {
        "sku": "VHANY6NT9U522MSM",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "8GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS3-ContainerSvcUsage:XLarge-4CPU-8GB",
          "operation": "ContainerSvc:XLarge-4CPU-8GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "XLarge",
          "servicename": "Amazon Lightsail"
        }
      },
      "2URYYRKY4RXKN5E7": {
        "sku": "2URYYRKY4RXKN5E7",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "usagetype": "DNS-Queries",
          "operation": "",
          "overageType": "DNS Queries",
          "servicename": "Amazon Lightsail"
        }
      },
      "NHQGRU9XWJYYDK67": {
        "sku": "NHQGRU9XWJYYDK67",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EU-BundleUsage:2GB_win",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "ZFV2MSENFZBB24HF": {
        "sku": "ZFV2MSENFZBB24HF",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUC1-ContainerSvcUsage:Micro-0.25CPU-1GB",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Micro",
          "servicename": "Amazon Lightsail"
        }
      },
      "7VKRQJYWPNFEVCSQ": {
        "sku": "7VKRQJYWPNFEVCSQ",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Canada",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "CA-CDN:200GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:200GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:200GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "2N8DBXND9NXTYHJU": {
        "sku": "2N8DBXND9NXTYHJU",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EU-BundleUsage:16GB",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "6TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "M2WNF6RFG8UH9TU6": {
        "sku": "M2WNF6RFG8UH9TU6",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUC1-BundleUsage:32GB",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "7TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "QF8HGH9S2FDWMNEJ": {
        "sku": "QF8HGH9S2FDWMNEJ",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "CAN1-BundleUsage:32GB_win",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "7TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "ER78ZXZJ59MHMJTR": {
        "sku": "ER78ZXZJ59MHMJTR",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "120GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUC1-DatabaseUsage:4GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "655SBVDQXJJY4HNS": {
        "sku": "655SBVDQXJJY4HNS",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "240GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "USE1-DatabaseUsage:8GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.2TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "STAFPV9FHXVW9C73": {
        "sku": "STAFPV9FHXVW9C73",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Asia Pacific (Tokyo)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "APN1-DataXfer-Out-Free-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "Yes",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "F3XZS564WZPQDBBY": {
        "sku": "F3XZS564WZPQDBBY",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "0.5GB",
          "storage": "20GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUW2-BundleUsage:0.5GB",
          "operation": "Bundle:0.5GB",
          "dataTransferQuota": "1TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "CA2PPNSJA6JQK5VH": {
        "sku": "CA2PPNSJA6JQK5VH",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Inbound",
          "fromLocation": "Global",
          "fromLocationType": "Other",
          "toLocation": "Canada (Central)",
          "toLocationType": "AWS Region",
          "usagetype": "CAN1-TotalDataXfer-In-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "Yes",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "5VRKB9MCP4VWRJMT": {
        "sku": "5VRKB9MCP4VWRJMT",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Asia Pacific (Tokyo)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "APN1-DataXfer-Out-Overage-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "4TFDR7RPK89TQ3PN": {
        "sku": "4TFDR7RPK89TQ3PN",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "8GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUW2-ContainerSvcUsage:XLarge-4CPU-8GB",
          "operation": "ContainerSvc:XLarge-4CPU-8GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "XLarge",
          "servicename": "Amazon Lightsail"
        }
      },
      "PD52ZNQ3RTYBK8XX": {
        "sku": "PD52ZNQ3RTYBK8XX",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "80GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUW2-BundleUsage:4GB",
          "operation": "Bundle:4GB",
          "dataTransferQuota": "4TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "G8F9MWX2ZVGMFWAG": {
        "sku": "G8F9MWX2ZVGMFWAG",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Europe",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EU-CDN:200GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:200GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:200GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "8MKXMM5AY7PABCR3": {
        "sku": "8MKXMM5AY7PABCR3",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE1-BundleUsage:32GB",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "7TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "25CXDSK42JX9QDKW": {
        "sku": "25CXDSK42JX9QDKW",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "CAN1-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "SCDJEHAMTUKMG8YK": {
        "sku": "SCDJEHAMTUKMG8YK",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS2-ContainerSvcUsage:Medium-1CPU-2GB",
          "operation": "ContainerSvc:Medium-1CPU-2GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Medium",
          "servicename": "Amazon Lightsail"
        }
      },
      "Z9MNSUZQU97D4RYY": {
        "sku": "Z9MNSUZQU97D4RYY",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "120GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUW2-DatabaseUsage:4GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "K6G9RT6RRAMSA88T": {
        "sku": "K6G9RT6RRAMSA88T",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Inbound",
          "fromLocation": "Global",
          "fromLocationType": "Other",
          "toLocation": "Asia Pacific (Sydney)",
          "toLocationType": "AWS Region",
          "usagetype": "APS2-TotalDataXfer-In-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "Yes",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "YS7SUSJT8STVWAJ8": {
        "sku": "YS7SUSJT8STVWAJ8",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE1-BundleUsage:32GB_win",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "7TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "EYJ8VTEM5G8EBABP": {
        "sku": "EYJ8VTEM5G8EBABP",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUC1-ContainerSvcUsage:Medium-1CPU-2GB",
          "operation": "ContainerSvc:Medium-1CPU-2GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Medium",
          "servicename": "Amazon Lightsail"
        }
      },
      "62U4UYT77BPJKPQC": {
        "sku": "62U4UYT77BPJKPQC",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "USW2-ContainerSvcUsage:Micro-0.25CPU-1GB",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Micro",
          "servicename": "Amazon Lightsail"
        }
      },
      "35RH6S8FHZHZCFNA": {
        "sku": "35RH6S8FHZHZCFNA",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USW2-BundleUsage:2GB",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "NREGWX3VY2ABR5KH": {
        "sku": "NREGWX3VY2ABR5KH",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "0.5GB",
          "storage": "30GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EU-BundleUsage:0.5GB_win",
          "operation": "Bundle:0.5GB",
          "dataTransferQuota": "1TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "R8HDCBU9TTVU8VDU": {
        "sku": "R8HDCBU9TTVU8VDU",
        "productFamily": "Lightsail Storage",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "storage": "1GB",
          "group": "Lightsail Block Storage",
          "groupDescription": "Amount of Lightsail block storage disk usage in GB-Month",
          "usagetype": "APN2-DiskUsage",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "XKF8H9FK53KWT72K": {
        "sku": "XKF8H9FK53KWT72K",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APS3-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "Y9XKWD64943VVTP7": {
        "sku": "Y9XKWD64943VVTP7",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "USW2-DatabaseUsage:2GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "SH428PJK6ZQ2J5K2": {
        "sku": "SH428PJK6ZQ2J5K2",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "USE1-DatabaseUsage:2GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "QFQ39ZM6J92UGYPV": {
        "sku": "QFQ39ZM6J92UGYPV",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "EU (London)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EUW2-TotalDataXfer-Out-Bytes",
          "operation": "",
          "countsAgainstQuota": "NA",
          "freeOverage": "NA",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "FDSACRA5N9BARS7N": {
        "sku": "FDSACRA5N9BARS7N",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUW2-BundleUsage:2GB_win",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "VPNG3ZFBRPGTGYZ6": {
        "sku": "VPNG3ZFBRPGTGYZ6",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "EU (Stockholm)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EUN1-DataXfer-Out-Overage-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "DPDXBEPKGCCWS6M4": {
        "sku": "DPDXBEPKGCCWS6M4",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS3-BundleUsage:2GB_win",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "1.5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "MG32U9GAVP67UM6P": {
        "sku": "MG32U9GAVP67UM6P",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Japan",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "JP-CDN:500GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:500GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "GZVKWHSS7HSHRJ22": {
        "sku": "GZVKWHSS7HSHRJ22",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Europe",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EU-CDN:200GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:200GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:200GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "HYUA89R3VR6J5FY7": {
        "sku": "HYUA89R3VR6J5FY7",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Paris)",
          "locationType": "AWS Region",
          "vcpu": "0.5",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUW3-ContainerSvcUsage:Small-0.5CPU-1GB",
          "operation": "ContainerSvc:Small-0.5CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Small",
          "servicename": "Amazon Lightsail"
        }
      },
      "R897JTFMHPZBX7GZ": {
        "sku": "R897JTFMHPZBX7GZ",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "160GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE1-BundleUsage:8GB_win",
          "operation": "Bundle:8GB",
          "dataTransferQuota": "5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "SZU8RJDBGGGTJB92": {
        "sku": "SZU8RJDBGGGTJB92",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Asia Pacific (Tokyo)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "APN1-TotalDataXfer-Out-Bytes",
          "operation": "",
          "countsAgainstQuota": "NA",
          "freeOverage": "NA",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "X4HDTNMYHX3GE5E5": {
        "sku": "X4HDTNMYHX3GE5E5",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USW2-BundleUsage:16GB_win",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "6TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "9BZB27S2Z7PGJD9P": {
        "sku": "9BZB27S2Z7PGJD9P",
        "productFamily": "Lightsail Snapshot",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "group": "Lightsail Snapshot",
          "groupDescription": "Amount of Lightsail Snapshots in GB-Month",
          "usagetype": "USE2-SnapshotUsage",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "SSA2CNXMD5ZVGM23": {
        "sku": "SSA2CNXMD5ZVGM23",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "US West (Oregon)",
          "fromLocationType": "AWS Region",
          "toLocation": "US West (Oregon)",
          "toLocationType": "AWS Region",
          "usagetype": "USW2-DataXfer-Out-Other-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "Yes",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "5ZYE88NY4YFH55C2": {
        "sku": "5ZYE88NY4YFH55C2",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS3-ContainerSvcUsage:Micro-0.25CPU-1GB",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Micro",
          "servicename": "Amazon Lightsail"
        }
      },
      "8Z4VHBAYJUHJNK7V": {
        "sku": "8Z4VHBAYJUHJNK7V",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APS2-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "22KPZ99HW63D8WWS": {
        "sku": "22KPZ99HW63D8WWS",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS2-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "AWK5HX2446FDK6EJ": {
        "sku": "AWK5HX2446FDK6EJ",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "EU (Paris)",
          "fromLocationType": "AWS Region",
          "toLocation": "EU (Paris)",
          "toLocationType": "AWS Region",
          "usagetype": "EUW3-DataXfer-Out-Other-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "Yes",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "CFVERQUPAWXSJ2CZ": {
        "sku": "CFVERQUPAWXSJ2CZ",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "USW2-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "E7PYRFDU2F4ZAJ4F": {
        "sku": "E7PYRFDU2F4ZAJ4F",
        "productFamily": "Lightsail Snapshot",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "group": "Lightsail Snapshot",
          "groupDescription": "Amount of Lightsail Snapshots in GB-Month",
          "usagetype": "CAN1-SnapshotUsage",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "8DNKXPF8G9MBWQ93": {
        "sku": "8DNKXPF8G9MBWQ93",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "CAN1-BundleUsage:16GB",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "6TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "7PYCCAYBBZSRQSQU": {
        "sku": "7PYCCAYBBZSRQSQU",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Canada (Central)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "CAN1-TotalDataXfer-Out-Bytes",
          "operation": "",
          "countsAgainstQuota": "NA",
          "freeOverage": "NA",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "CPFSBR3DQB39BX57": {
        "sku": "CPFSBR3DQB39BX57",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Asia Pacific (Sydney)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "APS2-DataXfer-Out-Free-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "Yes",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "U8MHZFACH23PGJ6S": {
        "sku": "U8MHZFACH23PGJ6S",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "USE1-DatabaseUsage:1GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "9S8M22S937GWXZD3": {
        "sku": "9S8M22S937GWXZD3",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Middle East",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "ME-CDN:200GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:200GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:200GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "VCHSS9PMM5ANUJ53": {
        "sku": "VCHSS9PMM5ANUJ53",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "USE2-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "FHU33V2WV9NCKJT8": {
        "sku": "FHU33V2WV9NCKJT8",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUC1-DatabaseUsage:2GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "75CXV87WXD594NDQ": {
        "sku": "75CXV87WXD594NDQ",
        "productFamily": "Lightsail Snapshot",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "group": "Lightsail Instance Snapshot",
          "groupDescription": "Number of Lightsail Instance snapshot in GB-Month",
          "usagetype": "USE2-InstanceSnapshot",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "78BE5Y35W96XW59R": {
        "sku": "78BE5Y35W96XW59R",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS2-ContainerSvcUsage:Micro-0.25CPU-1GB",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Micro",
          "servicename": "Amazon Lightsail"
        }
      },
      "PD9SGKQBVH53Z56Y": {
        "sku": "PD9SGKQBVH53Z56Y",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "US West (Oregon)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "USW2-TotalDataXfer-Out-Bytes",
          "operation": "",
          "countsAgainstQuota": "NA",
          "freeOverage": "NA",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "2HYF3DGQ2RSDPEMR": {
        "sku": "2HYF3DGQ2RSDPEMR",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "USW2-ContainerSvcUsage:Medium-1CPU-2GB",
          "operation": "ContainerSvc:Medium-1CPU-2GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Medium",
          "servicename": "Amazon Lightsail"
        }
      },
      "T4TQ45AJ754P8ZWY": {
        "sku": "T4TQ45AJ754P8ZWY",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APS1-DatabaseUsage:2GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "PEFJ65GQ4W28FRW3": {
        "sku": "PEFJ65GQ4W28FRW3",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS2-BundleUsage:1GB",
          "operation": "Bundle:1GB",
          "dataTransferQuota": "1TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "4R6HU5K3J6DZ7HQR": {
        "sku": "4R6HU5K3J6DZ7HQR",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Stockholm)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "160GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUN1-BundleUsage:8GB",
          "operation": "Bundle:8GB",
          "dataTransferQuota": "5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "BKTJHAGCHKKWK8RD": {
        "sku": "BKTJHAGCHKKWK8RD",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Stockholm)",
          "locationType": "AWS Region",
          "vcpu": "0.5",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUN1-ContainerSvcUsage:Small-0.5CPU-1GB",
          "operation": "ContainerSvc:Small-0.5CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Small",
          "servicename": "Amazon Lightsail"
        }
      },
      "5AEWYWQ4BT24ADW3": {
        "sku": "5AEWYWQ4BT24ADW3",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Paris)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUW3-ContainerSvcUsage:Large-2CPU-4GB",
          "operation": "ContainerSvc:Large-2CPU-4GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Large",
          "servicename": "Amazon Lightsail"
        }
      },
      "YSYTCTZQXX3VA2U5": {
        "sku": "YSYTCTZQXX3VA2U5",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "0.5",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EU-ContainerSvcUsage:Small-0.5CPU-1GB",
          "operation": "ContainerSvc:Small-0.5CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Small",
          "servicename": "Amazon Lightsail"
        }
      },
      "K3SNE3A9RER39ZZJ": {
        "sku": "K3SNE3A9RER39ZZJ",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "USE2-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "U2EPAZJPTKYJU5MA": {
        "sku": "U2EPAZJPTKYJU5MA",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "80GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE2-BundleUsage:4GB_win",
          "operation": "Bundle:4GB",
          "dataTransferQuota": "4TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "JSDKBM6NVNTH89BK": {
        "sku": "JSDKBM6NVNTH89BK",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APN2-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "UX4TABKJRTE2GK8Z": {
        "sku": "UX4TABKJRTE2GK8Z",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "160GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APN2-BundleUsage:8GB_win",
          "operation": "Bundle:8GB",
          "dataTransferQuota": "5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "2Q64N5AFRBK4DR8H": {
        "sku": "2Q64N5AFRBK4DR8H",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Europe",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EU-CDN:500GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:500GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "55T7NDYQQ82P2HFJ": {
        "sku": "55T7NDYQQ82P2HFJ",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Paris)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUW3-DatabaseUsage:2GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "UKBZPMQJDQUMAHFB": {
        "sku": "UKBZPMQJDQUMAHFB",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "CAN1-BundleUsage:2GB",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "6NZHSY9XAX4Q7K2T": {
        "sku": "6NZHSY9XAX4Q7K2T",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "EU (Frankfurt)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EUC1-TotalDataXfer-Out-Bytes",
          "operation": "",
          "countsAgainstQuota": "NA",
          "freeOverage": "NA",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "F6TDKJZCW6ZW6FW5": {
        "sku": "F6TDKJZCW6ZW6FW5",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS2-BundleUsage:32GB_win",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "3.5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "97SWRN2CVQK5JEY3": {
        "sku": "97SWRN2CVQK5JEY3",
        "productFamily": "Lightsail Storage",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "storage": "1GB",
          "group": "Lightsail Block Storage",
          "groupDescription": "Amount of Lightsail block storage disk usage in GB-Month",
          "usagetype": "USE1-DiskUsage",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "8MV7685FHGC9RS7G": {
        "sku": "8MV7685FHGC9RS7G",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "240GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUW2-DatabaseUsage:8GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.2TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "AN2XXQRRVQ6EEWZX": {
        "sku": "AN2XXQRRVQ6EEWZX",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "group": "Lightsail unused static IP",
          "groupDescription": "Number of unused Lightsail static IP hours",
          "usagetype": "USE1-UnusedStaticIP",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "TTTKHM6NNWKJVDKF": {
        "sku": "TTTKHM6NNWKJVDKF",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "240GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APN2-DatabaseUsage:8GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.2TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "9DC8CGC6A3KWZYVN": {
        "sku": "9DC8CGC6A3KWZYVN",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Canada",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "CA-CDN:500GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:500GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "MM5G9A99PM22KNG3": {
        "sku": "MM5G9A99PM22KNG3",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS3-BundleUsage:16GB",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "CTE3K7UHRBD67RWW": {
        "sku": "CTE3K7UHRBD67RWW",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "EUW2-DatabaseUsage:2GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "H5WEBBHGY8BVWDS6": {
        "sku": "H5WEBBHGY8BVWDS6",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "240GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APS1-DatabaseUsage:8GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.2TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "SHHFWCWTBB2BK2UK": {
        "sku": "SHHFWCWTBB2BK2UK",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "EU (Ireland)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EU-TotalDataXfer-Out-Bytes",
          "operation": "",
          "countsAgainstQuota": "NA",
          "freeOverage": "NA",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "XHEJJ2P7Q84Z6HZZ": {
        "sku": "XHEJJ2P7Q84Z6HZZ",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "APS2-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "D8G7QKHTWJG52Y2F": {
        "sku": "D8G7QKHTWJG52Y2F",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "USE2-ContainerSvcUsage:Large-2CPU-4GB",
          "operation": "ContainerSvc:Large-2CPU-4GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Large",
          "servicename": "Amazon Lightsail"
        }
      },
      "DBTECGU9CKTY5GMR": {
        "sku": "DBTECGU9CKTY5GMR",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "group": "Lightsail CDN",
          "groupDescription": "Lightsail CDN bundle subscription fee",
          "usagetype": "CDN-BundleUsage:50GB_FreeTrial",
          "operation": "CDN-Bundle:50GB_FreeTrial",
          "dataTransferQuota": "50GB (Free Trial)",
          "servicename": "Amazon Lightsail"
        }
      },
      "RBWXJ39PGVRFUV5D": {
        "sku": "RBWXJ39PGVRFUV5D",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Sydney)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "160GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS2-BundleUsage:8GB_win",
          "operation": "Bundle:8GB",
          "dataTransferQuota": "2.5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "7VFUHBH3DFDJDFX3": {
        "sku": "7VFUHBH3DFDJDFX3",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APN2-ContainerSvcUsage:Micro-0.25CPU-1GB",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Micro",
          "servicename": "Amazon Lightsail"
        }
      },
      "885PZYJVF9MANGG7": {
        "sku": "885PZYJVF9MANGG7",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Tokyo)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "0.5GB",
          "storage": "20GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APN1-BundleUsage:0.5GB",
          "operation": "Bundle:0.5GB",
          "dataTransferQuota": "1TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "9U6WQTCUEQ2FC9FZ": {
        "sku": "9U6WQTCUEQ2FC9FZ",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "India",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "IN-CDN:500GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:500GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "HC3UU6U36FDCD3V2": {
        "sku": "HC3UU6U36FDCD3V2",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS1-ContainerSvcUsage:Large-2CPU-4GB",
          "operation": "ContainerSvc:Large-2CPU-4GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Large",
          "servicename": "Amazon Lightsail"
        }
      },
      "EHME2E4SR2XE7625": {
        "sku": "EHME2E4SR2XE7625",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS1-BundleUsage:1GB",
          "operation": "Bundle:1GB",
          "dataTransferQuota": "2TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "6EUVQ54SYD6PBM2Z": {
        "sku": "6EUVQ54SYD6PBM2Z",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "South Africa",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "ZA-CDN:50GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:50GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:50GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "2ARR857RTG59N25A": {
        "sku": "2ARR857RTG59N25A",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Tokyo)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APN1-ContainerSvcUsage:Large-2CPU-4GB",
          "operation": "ContainerSvc:Large-2CPU-4GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Large",
          "servicename": "Amazon Lightsail"
        }
      },
      "8KVFXNG36YFNZAKZ": {
        "sku": "8KVFXNG36YFNZAKZ",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "South America",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "SA-CDN:200GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:200GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:200GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "E858FCFDZN556JE3": {
        "sku": "E858FCFDZN556JE3",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (London)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUW2-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "JS8SQCWDNRDT8QF2": {
        "sku": "JS8SQCWDNRDT8QF2",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Stockholm)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "EUN1-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "AV4W8UP6KJHRATBP": {
        "sku": "AV4W8UP6KJHRATBP",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APS1-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "RMUMFYU5ZKWPSZAV": {
        "sku": "RMUMFYU5ZKWPSZAV",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Frankfurt)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUC1-BundleUsage:2GB",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "SUWKYTZ9RPDNF2CM": {
        "sku": "SUWKYTZ9RPDNF2CM",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "CAN1-DatabaseUsage:1GB",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "No",
          "servicename": "Amazon Lightsail"
        }
      },
      "SEAND6E6JBTAKEYM": {
        "sku": "SEAND6E6JBTAKEYM",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Paris)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUW3-BundleUsage:32GB",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "7TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "GWB9QDQ8U52XR889": {
        "sku": "GWB9QDQ8U52XR889",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Tokyo)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APN1-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "4G4M8ZBRKVF22GR5": {
        "sku": "4G4M8ZBRKVF22GR5",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "80GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE1-BundleUsage:4GB_win",
          "operation": "Bundle:4GB",
          "dataTransferQuota": "4TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "9B6KPPJG3HT8K77S": {
        "sku": "9B6KPPJG3HT8K77S",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Japan",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "JP-CDN:500GB-TotalDataXfer-Out-Bytes",
          "operation": "CDN:500GB-TotalDataXfer-Out",
          "countsAgainstQuota": "Yes",
          "freeOverage": "NA",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "MQZFVMDGSKN7KJ4X": {
        "sku": "MQZFVMDGSKN7KJ4X",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "8GB",
          "storage": "160GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS3-BundleUsage:8GB",
          "operation": "Bundle:8GB",
          "dataTransferQuota": "2.5TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "QSMU4KCPV6RUD4DQ": {
        "sku": "QSMU4KCPV6RUD4DQ",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "USE2-ContainerSvcUsage:Medium-1CPU-2GB",
          "operation": "ContainerSvc:Medium-1CPU-2GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Medium",
          "servicename": "Amazon Lightsail"
        }
      },
      "5GM5KFVXCGRG65U8": {
        "sku": "5GM5KFVXCGRG65U8",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EU-ContainerSvcUsage:Large-2CPU-4GB",
          "operation": "ContainerSvc:Large-2CPU-4GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Large",
          "servicename": "Amazon Lightsail"
        }
      },
      "M24K3SFC6STMWHTW": {
        "sku": "M24K3SFC6STMWHTW",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "1GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "APS3-ContainerSvcUsage:Micro-0.25CPU-1GB-Free",
          "operation": "ContainerSvc:Micro-0.25CPU-1GB",
          "dataTransferQuota": "500GB",
          "isfree": "Yes",
          "power": "Micro (Free)",
          "servicename": "Amazon Lightsail"
        }
      },
      "QPV56SZVAQF3DHBE": {
        "sku": "QPV56SZVAQF3DHBE",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (Ohio)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE2-BundleUsage:1GB",
          "operation": "Bundle:1GB",
          "dataTransferQuota": "2TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "GPJC77FKCUFCA44V": {
        "sku": "GPJC77FKCUFCA44V",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS1-BundleUsage:16GB",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "6TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "NDQXPUSZ6VX9TBR3": {
        "sku": "NDQXPUSZ6VX9TBR3",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APN2-DatabaseUsage:1GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "7VVTA4CHRSBQWWGB": {
        "sku": "7VVTA4CHRSBQWWGB",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "CAN1-DatabaseUsage:1GB_ha",
          "operation": "RelationalDatabase",
          "dataTransferQuota": "0.1TB",
          "engine": "MySQL/PostgreSQL",
          "highAvailability": "Yes",
          "servicename": "Amazon Lightsail"
        }
      },
      "SERFNMGES364J829": {
        "sku": "SERFNMGES364J829",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Australia",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "AU-CDN:500GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:500GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:500GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "83MN2S6HA7YRCABK": {
        "sku": "83MN2S6HA7YRCABK",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "APN2-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "5CS3SPCKPQ5V7NXV": {
        "sku": "5CS3SPCKPQ5V7NXV",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "South Africa",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "ZA-CDN:50GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:50GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:50GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "4979FU2TH2ERBWFW": {
        "sku": "4979FU2TH2ERBWFW",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Stockholm)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EUN1-BundleUsage:2GB",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "37PP4FD27VHEQU2H": {
        "sku": "37PP4FD27VHEQU2H",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "EU-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "XKYYXFW6H98FCT3A": {
        "sku": "XKYYXFW6H98FCT3A",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Tokyo)",
          "locationType": "AWS Region",
          "group": "Lightsail unused static IP",
          "groupDescription": "Number of unused Lightsail static IP hours",
          "usagetype": "APN1-UnusedStaticIP",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "ZWPZJ93R2HNBQYZ7": {
        "sku": "ZWPZJ93R2HNBQYZ7",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Canada (Central)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "0.5GB",
          "storage": "30GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "CAN1-BundleUsage:0.5GB_win",
          "operation": "Bundle:0.5GB",
          "dataTransferQuota": "1TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "GQBK6X3MM6XACCT8": {
        "sku": "GQBK6X3MM6XACCT8",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "0.5GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EU-ContainerSvcUsage:Nano-0.25CPU-0.5GB",
          "operation": "ContainerSvc:Nano-0.25CPU-0.5GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Nano",
          "servicename": "Amazon Lightsail"
        }
      },
      "EZ9QFPG6SW7ASBPB": {
        "sku": "EZ9QFPG6SW7ASBPB",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "vcpu": "2",
          "memory": "4GB",
          "storage": "80GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APS1-BundleUsage:4GB",
          "operation": "Bundle:4GB",
          "dataTransferQuota": "4TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "XWNWJJMZVH4UCYCY": {
        "sku": "XWNWJJMZVH4UCYCY",
        "productFamily": "Lightsail Load Balancing",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Singapore)",
          "locationType": "AWS Region",
          "group": "Lightsail Load Balancer",
          "groupDescription": "Number of Lightsail Load Balancer hours",
          "usagetype": "APS1-LoadBalancerUsage",
          "operation": "LoadBalancer",
          "servicename": "Amazon Lightsail"
        }
      },
      "NSJGKDS3EC53VZWK": {
        "sku": "NSJGKDS3EC53VZWK",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "vcpu": "8",
          "memory": "32GB",
          "storage": "640GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "EU-BundleUsage:32GB_win",
          "operation": "Bundle:32GB",
          "dataTransferQuota": "7TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "PX3BVGTP9Z3F38GW": {
        "sku": "PX3BVGTP9Z3F38GW",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "South Africa",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "ZA-CDN:200GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:200GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:200GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "QUKMCPWKHG9B3AUS": {
        "sku": "QUKMCPWKHG9B3AUS",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US East (N. Virginia)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "60GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "USE1-BundleUsage:2GB_win",
          "operation": "Bundle:2GB",
          "dataTransferQuota": "3TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "PS4TEPMECJ9KZVFM": {
        "sku": "PS4TEPMECJ9KZVFM",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Mumbai)",
          "locationType": "AWS Region",
          "group": "Lightsail unused static IP",
          "groupDescription": "Number of unused Lightsail static IP hours",
          "usagetype": "APS3-UnusedStaticIP",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "KV4HZ2KC2HQS8KY6": {
        "sku": "KV4HZ2KC2HQS8KY6",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "Asia Pacific",
          "fromLocationType": "AWS Edge Location",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "AP-CDN:50GB-DataXfer-Out-Overage-Bytes",
          "operation": "CDN:50GB-DataXfer-Out-Overage",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "CDN:50GB Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "56V25H6MGYYP8PGT": {
        "sku": "56V25H6MGYYP8PGT",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "US West (Oregon)",
          "locationType": "AWS Region",
          "vcpu": "0.25",
          "memory": "0.5GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "USW2-ContainerSvcUsage:Nano-0.25CPU-0.5GB",
          "operation": "ContainerSvc:Nano-0.25CPU-0.5GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "Nano",
          "servicename": "Amazon Lightsail"
        }
      },
      "8RXP4C45HNNWMVQ6": {
        "sku": "8RXP4C45HNNWMVQ6",
        "productFamily": "Lightsail Networking",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "group": "Lightsail Overages",
          "groupDescription": "Lightsail overages - usage above allocated free quota",
          "transferType": "AWS Outbound",
          "fromLocation": "EU (Ireland)",
          "fromLocationType": "AWS Region",
          "toLocation": "Global",
          "toLocationType": "Other",
          "usagetype": "EU-DataXfer-Out-Overage-Bytes",
          "operation": "",
          "countsAgainstQuota": "Yes",
          "freeOverage": "No",
          "overageType": "Data Transfer",
          "servicename": "Amazon Lightsail"
        }
      },
      "MAF4M85GPJJF83MQ": {
        "sku": "MAF4M85GPJJF83MQ",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "1GB",
          "storage": "40GB",
          "operatingSystem": "Linux",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APN2-BundleUsage:1GB",
          "operation": "Bundle:1GB",
          "dataTransferQuota": "2TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "QTUE7VHU5Q7RWWNC": {
        "sku": "QTUE7VHU5Q7RWWNC",
        "productFamily": "Lightsail Snapshot",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Ireland)",
          "locationType": "AWS Region",
          "group": "Lightsail Instance Snapshot",
          "groupDescription": "Number of Lightsail Instance snapshot in GB-Month",
          "usagetype": "EU-InstanceSnapshot",
          "operation": "",
          "servicename": "Amazon Lightsail"
        }
      },
      "FDAYA8B4327XNZ7C": {
        "sku": "FDAYA8B4327XNZ7C",
        "productFamily": "Lightsail Containers",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "EU (Paris)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "8GB",
          "storage": "NA",
          "operatingSystem": "Linux",
          "group": "Lightsail Container",
          "groupDescription": "Number of Lightsail Container Service hours",
          "usagetype": "EUW3-ContainerSvcUsage:XLarge-4CPU-8GB",
          "operation": "ContainerSvc:XLarge-4CPU-8GB",
          "dataTransferQuota": "500GB",
          "isfree": "No",
          "power": "XLarge",
          "servicename": "Amazon Lightsail"
        }
      },
      "G9NHCETZ4PY2N3UN": {
        "sku": "G9NHCETZ4PY2N3UN",
        "productFamily": "Lightsail Instance",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Tokyo)",
          "locationType": "AWS Region",
          "vcpu": "4",
          "memory": "16GB",
          "storage": "320GB",
          "operatingSystem": "Windows",
          "group": "Lightsail Instance",
          "groupDescription": "Number of Lightsail Instance hours",
          "usagetype": "APN1-BundleUsage:16GB_win",
          "operation": "Bundle:16GB",
          "dataTransferQuota": "6TB",
          "servicename": "Amazon Lightsail"
        }
      },
      "J9UFPRENVNAUJ2BS": {
        "sku": "J9UFPRENVNAUJ2BS",
        "productFamily": "Lightsail Database",
        "attributes": {
          "servicecode": "AmazonLightsail",
          "location": "Asia Pacific (Seoul)",
          "locationType": "AWS Region",
          "vcpu": "1",
          "memory": "2GB",
          "storage": "80GB",
          "group": "Lightsail Database",
          "groupDescription": "Number of Lightsail Database hours",
          "usagetype": "APN2-DatabaseUsage:2GB_ha",
          "operation": "RelationalDatabase"
        }
      }
    }
  }